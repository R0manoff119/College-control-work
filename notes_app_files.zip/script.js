let notes = [];

try {
  notes = JSON.parse(localStorage.getItem("myNotes") || "[]");
  if (!Array.isArray(notes)) notes = [];
} catch {
  notes = [];
}

function saveNotes() {
  localStorage.setItem("myNotes", JSON.stringify(notes));
}

function addNote() {
  const input = document.getElementById("noteInput");
  const text = input.value.trim();

  if (!text) {
    alert("Введите текст заметки!");
    return;
  }

  notes.unshift({
    id: Date.now().toString() + Math.random().toString(36).slice(2),
    text,
    date: new Date().toLocaleString("ru-RU")
  });

  saveNotes();
  renderNotes();
  input.value = "";
  input.focus();
}

function deleteNote(id) {
  notes = notes.filter(note => note.id !== id);
  saveNotes();
  renderNotes();
}

function renderNotes() {
  const list = document.getElementById("notesList");
  list.replaceChildren();

  if (notes.length === 0) {
    const empty = document.createElement("p");
    empty.textContent = "Заметок пока нет.";
    list.appendChild(empty);
    return;
  }

  notes.forEach(note => {
    const div = document.createElement("div");
    div.className = "note";

    const content = document.createElement("div");

    const date = document.createElement("div");
    date.className = "date";
    date.textContent = note.date || "";

    const text = document.createElement("div");
    text.className = "note-text";
    text.textContent = note.text;

    content.append(date, text);

    const button = document.createElement("button");
    button.className = "delete";
    button.textContent = "Удалить";
    button.type = "button";
    button.addEventListener("click", () => deleteNote(note.id));

    div.append(content, button);
    list.appendChild(div);
  });
}

document.getElementById("addButton").addEventListener("click", addNote);

document.getElementById("noteInput").addEventListener("keydown", event => {
  if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
    addNote();
  }
});

renderNotes();
